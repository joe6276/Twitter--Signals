import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { PostService } from '../post.service';

@Component({
  selector: 'app-post',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
constructor(private postService:PostService){}
posts$= this.postService.userPostsanDetails

ngOnInit(): void {
  this.posts$.subscribe(Posts=>{
       this.postService.setPostId(Posts[0].id)
  })
}
changeComments(id:number){
  this.postService.setPostId(id)
}
}
