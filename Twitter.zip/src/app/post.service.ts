
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Comments, Post, User, UserPosts } from './interfaces';
import { BehaviorSubject, Observable, Subject, catchError, combineLatest, map, switchMap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private http:HttpClient) { }

  private selectedUser= new BehaviorSubject<number|null>(null)
  selectedUser$= this.selectedUser.asObservable()

  private selectedPost= new BehaviorSubject<number>(1)
  selectedPost$= this.selectedPost.asObservable()

  users$= this.http.get<User[]> ('https://jsonplaceholder.typicode.com/users')
  posts$= this.http.get<Post[]> ('https://jsonplaceholder.typicode.com/posts')
  comments$= this.http.get<Comments[]> ('https://jsonplaceholder.typicode.com/comments')
  
  selectedUserdetails$= this.selectedUser$.pipe(
    switchMap(userId=> this.http.get<User>(`https://jsonplaceholder.typicode.com/users/${userId}`))
  )

  userPosts$= combineLatest([
    this.selectedUserdetails$,
    this.posts$
  ]).pipe(
    map(([userDetails,posts])=>{
      return posts.filter(post=> post.userId ===userDetails.id).map<UserPosts>(post=>({
        ...post,
        userDetails
      }))
    })
  )

  postComments$ = combineLatest([
    this.selectedPost$,
    this.comments$
  ]).pipe(
    map(([postid,comments])=> comments.filter(comment=>comment.postId === postid)),
    catchError(this.handleError)
  )


userPostsanDetails= combineLatest([
  this.userPosts$,
  this.selectedUserdetails$
]).pipe(
  map(([posts,userDetails])=>
  posts.map<UserPosts>(post=>({
    ...post,
    userDetails
  })))
)
  setFirstUser(){
    this.users$.subscribe(users=>{
      this.selectedUser.next(users[0].id)
    })
  }

  setUserId(id:number){
    this.selectedUser.next(id)
  }

  setPostId(id:number){
    this.selectedPost.next(id)
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message
        }`;
    }
    console.error(errorMessage);
    return throwError(() => errorMessage);
  }

}
