import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostService } from '../post.service';
import { Observable } from 'rxjs';
import { Comments } from '../interfaces';

@Component({
  selector: 'app-comment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit{

  constructor(private postService:PostService){}
  comments$= this.postService.postComments$
  
  ngOnInit(): void {
    
    this.postService.postComments$.subscribe(comment=>{
      comment
    },
    
    error=>{
      console.log(error);
      
    })
  }
}
